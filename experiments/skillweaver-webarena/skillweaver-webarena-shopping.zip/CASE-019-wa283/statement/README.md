# WebArena Shopping task 283

Website: http://localhost:7770 (an online store; you are already signed in as its customer in the agent browser)
Start page: http://localhost:7770

## Task

Look up the most recent models of XBox controllers released between 2020-2021?

## How to answer

Start from the specified page. Access this website only with `penguin browser` and any registered SkillWeaver APIs that invoke it. Do not use `curl`, `wget`, standalone HTTP clients or other browser tools, including for verification or fallback. Browser scripts remain within the site's origin. Keep your Agent State, including memory, read-only. Do not sign out, change the account, or buy anything.
When you are on the page the task asks for, stay there and run `penguin browser tabs` as your last command, so the page you ended on is recorded.
Then end your final reply with one line `ANSWER: done`.
