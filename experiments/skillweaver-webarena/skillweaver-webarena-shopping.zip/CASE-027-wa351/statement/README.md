# WebArena Shopping task 351

Website: http://localhost:7770 (an online store; you are already signed in as its customer in the agent browser)
Start page: http://localhost:7770

## Task

List products from PS4 accessories category by ascending price

## How to answer

Work in the agent browser with `penguin browser`, on this website only, starting from the start page. Do not sign out, change the account, or buy anything.
When you are on the page the task asks for, stay there and run `penguin browser tabs` as your last command, so the page you ended on is recorded.
Then end your final reply with one line `ANSWER: done`.
