# WebArena Shopping task 319

Website: http://localhost:7770 (an online store; you are already signed in as its customer in the agent browser)
Start page: http://localhost:7770

## Task

How much refund I should expect from my order canlled in April 2022, including shipping fee

## How to answer

Work in the agent browser with `penguin browser`, on this website only, starting from the start page. Do not sign out, change the account, or buy anything.
End your final reply with one line `ANSWER: <your answer>`. If the task cannot be done on this website, answer `ANSWER: N/A` and say why in one sentence above it.
