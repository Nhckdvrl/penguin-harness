# WebArena Shopping task 319

Website: http://localhost:7770 (an online store; you are already signed in as its customer in the agent browser)
Start page: http://localhost:7770

## Task

How much refund I should expect from my order canlled in April 2022, including shipping fee

## How to answer

Start from the specified page. Access this website only with `penguin browser` and any registered SkillWeaver APIs that invoke it. Do not use `curl`, `wget`, standalone HTTP clients, other browser tools, or direct requests from browser scripts, including for verification or fallback. Keep your Agent State, including memory, read-only. Do not sign out, change the account, or buy anything.
End your final reply with one line `ANSWER: <your answer>`. If the task cannot be done on this website, answer `ANSWER: N/A` and say why in one sentence above it.
