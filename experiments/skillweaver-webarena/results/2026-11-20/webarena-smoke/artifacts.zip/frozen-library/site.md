# One Stop Market

A Magento online store at http://localhost:7770 with a mixed catalogue — pantry and grocery goods, teas, seasonings, home furnishings and apparel. Pages are server-rendered Magento: an account header with My Account, My Wish List, Compare Products and Sign Out, a "My Cart" mini-cart showing the item count, and a `form_key` hidden input on every form. Every page also carries a standing "JavaScript seems to be disabled in your browser" notice that is unrelated to the outcome of any action and can be ignored when reading page messages.

## Catalog search

The search lives at `/catalogsearch/result/?q=<words>` and is a substring match on product names; a shopper's plain wording works, including apostrophes and commas, which need no escaping. Results are list items, each headed by a product link (`a.product-item-link`) to the product page, with the price, the review count and the add-to-cart form beside it. Each listing's link element also holds an inline style block, so a link's text can come back containing CSS — ignore any text containing `{`. A search with no matches shows a "Your search returned no results." notice in place of the listings.

## Adding to cart from the search results

Every product listing carries its own add-to-cart form (`form[data-role="tocart-form"]`) with hidden `product`, `uenc` and `form_key` inputs. Submitting it posts to `/checkout/cart/add/uenc/<uenc>/product/<product id>/` and adds one unit of the product; the response redirects back to the page the form was sent from. Products with a required custom option behave differently: the listing form's action points back at the product page URL instead of the cart endpoint, so posting it only reopens the product page and nothing is added.

## Product page

A product page (`/<product-slug>.html`) holds the add-to-cart form (`form#product_addtocart_form`) with hidden `product`, `item`, `selected_configurable_option`, `related_product` and `form_key` inputs, a `qty` number input, and the product's custom option groups (`options[<option id>]`, rendered as radios or a select, each with a label). Some option groups are required; submitting the form without a choice reopens the product page with an error. Submitting it with a choice made adds the product with that option and the given quantity.

## Cart

The cart page is `/checkout/cart/`. Each line is a `.cart.item` row with the product name, a link to the product page and a quantity input named `cart[<item id>][qty]`. The page's form, whose action is `/checkout/cart/updatePost/`, changes quantities: post `form_key` plus one `cart[<item id>][qty]` entry per line to be changed. A successful add-to-cart shows a success message on the page it returns to, and adding a unit of a product already in the cart raises that line's quantity instead of replacing it, so a repeated add of the same product shows quantity 2 on the line.
