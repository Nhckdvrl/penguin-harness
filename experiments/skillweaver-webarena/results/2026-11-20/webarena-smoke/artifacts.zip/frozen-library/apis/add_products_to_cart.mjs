import { browser, runApi } from "./skillweaver-api.mjs";

export const meta = {
  name: "add_products_to_cart",
  description:
    "Add products to the shopping cart by name, using the store's own catalog search and " +
    "add-to-cart forms. For each name the search page is queried, the listing whose name best " +
    "matches is picked, and that listing's add-to-cart form is submitted once. Unexpected but " +
    "useful: when a product has a required custom option (a size or pack choice), the listing's " +
    "form posts back to the product page instead of the cart endpoint, so nothing is added from " +
    "the listing — the product page's own add-to-cart form is submitted instead, taking the " +
    "already-checked choice or, failing that, the first choice of every option group, and " +
    "reporting which was taken. Adding a unit of a product already in the cart raises that " +
    "line's quantity rather than replacing it, so the cart page is read back afterwards and the " +
    "quantities reported are the ones the cart actually holds.",
  params: {
    products: {
      type: "string",
      description:
        "Product names to add, one per line, worded as a shopper would type them into the search box.",
    },
    quantity: {
      type: "number",
      description: "Units of each product to add; leave out for one.",
      optional: true,
    },
  },
  returns:
    "An object {added: [...], cart: [...]}. added holds one entry per requested product: " +
    "{requested, matched, added, quantity, options, error, note} — matched is the listing title " +
    "it was found under, added and quantity describe that product's line on the cart afterwards, " +
    "options maps each required option group to the choice taken, and error or note explains a " +
    "failure. cart lists every item on the cart page afterwards as {name, quantity}.",
  usage_log: [
    "iter_0: added 'Stove Top Turkey Stuffing Mix', \"Tony Chachere's More Spice Creole Seasoning\" " +
    "and 'Elmwood Inn Fine Teas, Orange Vanilla Caffeine-free Fruit Infusion, 16-Ounce Pouch' with " +
    "quantity 1; all three were on /checkout/cart/ afterwards. The two seasonings were added by " +
    "their listings' forms, which post straight to /checkout/cart/add/; the Stove Top listing's " +
    "form posts to the product page because the product has a required custom option " +
    "(options[71138]), so it was added from the product page with the first radio choice, " +
    "'12 Ounce (Pack of 1)'.",
  ],
};

export async function run({ products, quantity }) {
  const names = String(products)
    .split(/\r?\n/)
    .map((name) => name.trim())
    .filter(Boolean);
  const qty = typeof quantity === "number" && quantity > 0 ? Math.floor(quantity) : 1;
  browser.open("/");
  browser.waitFor("document.querySelector('input[name=\"form_key\"]')");
  return browser.exec(`
    const names = ${JSON.stringify(names)};
    const qty = ${qty};
    let formKey = document.querySelector('input[name="form_key"]')?.value || '';
    const norm = (s) => (s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    const score = (text, target) => {
      if (text === target) return 100;
      if (text.includes(target) || target.includes(text)) return 60;
      const words = new Set(text.split(' '));
      const wanted = target.split(' ');
      return wanted.filter((w) => w.length > 2 && words.has(w)).length / Math.max(1, wanted.length) * 30;
    };
    const parse = async (path) => new DOMParser().parseFromString(
      await (await fetch(path, { credentials: 'include' })).text(), 'text/html');
    const hiddenInputs = (form) => {
      const params = {};
      form.querySelectorAll('input[type=hidden]').forEach((i) => { if (i.name) params[i.name] = i.value; });
      return params;
    };
    const postForm = async (url, params) => {
      const r = await fetch(url, {
        method: 'POST', credentials: 'include', redirect: 'follow',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams(params).toString(),
      });
      const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
      const error = doc.querySelector('.message.error');
      return { error: error ? (error.innerText || '').trim().slice(0, 200) : null };
    };
    const added = [];
    for (const requested of names) {
      const searchDoc = await parse('/catalogsearch/result/?q=' + encodeURIComponent(requested));
      if (!formKey) formKey = searchDoc.querySelector('input[name="form_key"]')?.value || '';
      const links = [...searchDoc.querySelectorAll('a.product-item-link')]
        .map((a) => ({ a: a, text: (a.innerText || '').trim() }))
        .filter((x) => x.text && !x.text.includes('{'));
      let best = null, bestScore = -1;
      for (const x of links) {
        const s = score(norm(x.text), norm(requested));
        if (s > bestScore) { bestScore = s; best = x.a; }
      }
      if (!best) {
        added.push({ requested: requested, matched: null, added: false, quantity: 0,
          note: 'no product found under this name in the search results' });
        continue;
      }
      const matched = (best.innerText || '').trim();
      const item = best.closest('li.item.product-item') || best.closest('.product-item-info') || best.parentElement;
      const listingForm = item ? item.querySelector('form[data-role="tocart-form"]') : null;
      const action = listingForm ? listingForm.getAttribute('action') || '' : '';
      const entry = { requested: requested, matched: matched, options: null, error: null };
      let result;
      if (action.includes('/checkout/cart/add/')) {
        const params = hiddenInputs(listingForm);
        if (!params.form_key) params.form_key = formKey;
        params.qty = String(qty);
        result = await postForm(action, params);
      } else {
        const productDoc = await parse(best.getAttribute('href'));
        const productForm = productDoc.querySelector('form#product_addtocart_form, form[data-role="tocart-form"]');
        if (!productForm) {
          entry.note = 'no add-to-cart form on the product page';
          added.push(entry);
          continue;
        }
        const params = hiddenInputs(productForm);
        if (!params.form_key) params.form_key = formKey;
        params.qty = String(qty);
        const groups = {};
        productForm.querySelectorAll('input[name^="options["], select[name^="options["]').forEach((el) => {
          if (!groups[el.name]) groups[el.name] = { choices: [], checked: null };
          const label = el.id ? productDoc.querySelector('label[for="' + el.id + '"]') : null;
          const text = label ? (label.innerText || '').trim() : '';
          if (el.tagName === 'SELECT') {
            for (const o of el.options) if (o.value) groups[el.name].choices.push({ value: o.value, label: o.text });
          } else {
            groups[el.name].choices.push({ value: el.value, label: text });
            if (el.checked) groups[el.name].checked = { value: el.value, label: text };
          }
        });
        entry.options = {};
        for (const group of Object.keys(groups)) {
          const chosen = groups[group].checked || groups[group].choices[0];
          if (chosen) { params[group] = chosen.value; entry.options[group] = chosen.label || chosen.value; }
        }
        result = await postForm(productForm.getAttribute('action'), params);
      }
      entry.error = result.error;
      added.push(entry);
    }
    const cartDoc = await parse('/checkout/cart/');
    const cart = [...cartDoc.querySelectorAll('.cart.item')].map((el) => {
      const qtyInput = el.querySelector('input[name$="[qty]"]');
      const name = [...el.querySelectorAll('.product-item-name, .product-item-link, a')]
        .map((x) => (x.innerText || '').trim())
        .find((t) => t && !t.includes('{'));
      return { name: name || '', quantity: Number(qtyInput && qtyInput.value) || 0 };
    });
    for (const entry of added) {
      const target = entry.matched ? norm(entry.matched) : '';
      const line = target
        ? cart.find((c) => { const n = norm(c.name); return n === target || n.includes(target) || target.includes(n); })
        : null;
      entry.added = !!line;
      entry.quantity = line ? line.quantity : 0;
    }
    return { added: added, cart: cart };
  `);
}

runApi(import.meta.url, meta, run);
