# Skill library for http://localhost:7770

Each API below is a script beside this file. Call it from the shell as
`node <this directory>/<name>.mjs --args '<JSON object of its parameters>'`; it drives the agent
browser and prints one JSON line, `{"ok":true,"result":…}` or `{"ok":false,"error":"…"}`.
Where the shell mangles quotes (Windows PowerShell), write the JSON to a file and pass
`--args-file <file>` instead.

## add_products_to_cart(products: string, quantity?: number)

Add products to the shopping cart by name, using the store's own catalog search and add-to-cart forms. For each name the search page is queried, the listing whose name best matches is picked, and that listing's add-to-cart form is submitted once. Unexpected but useful: when a product has a required custom option (a size or pack choice), the listing's form posts back to the product page instead of the cart endpoint, so nothing is added from the listing — the product page's own add-to-cart form is submitted instead, taking the already-checked choice or, failing that, the first choice of every option group, and reporting which was taken. Adding a unit of a product already in the cart raises that line's quantity rather than replacing it, so the cart page is read back afterwards and the quantities reported are the ones the cart actually holds.

- `products` (string): Product names to add, one per line, worded as a shopper would type them into the search box.
- `quantity` (number, optional): Units of each product to add; leave out for one.

Returns: An object {added: [...], cart: [...]}. added holds one entry per requested product: {requested, matched, added, quantity, options, error, note} — matched is the listing title it was found under, added and quantity describe that product's line on the cart afterwards, options maps each required option group to the choice taken, and error or note explains a failure. cart lists every item on the cart page afterwards as {name, quantity}.

Version 1; tested 1 time(s).

Usage log:
- iter_0: added 'Stove Top Turkey Stuffing Mix', "Tony Chachere's More Spice Creole Seasoning" and 'Elmwood Inn Fine Teas, Orange Vanilla Caffeine-free Fruit Infusion, 16-Ounce Pouch' with quantity 1; all three were on /checkout/cart/ afterwards. The two seasonings were added by their listings' forms, which post straight to /checkout/cart/add/; the Stove Top listing's form posts to the product page because the product has a required custom option (options[71138]), so it was added from the product page with the first radio choice, '12 Ounce (Pack of 1)'.
