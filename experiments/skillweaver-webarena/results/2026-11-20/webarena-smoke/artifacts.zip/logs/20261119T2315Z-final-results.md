# SkillWeaver drill — final results hand-off (written 2026-11-19T23:15Z UTC)

Experiment `sw_shop_smoke-20261119T220911Z`. Everything is measured, recorded and verified. The only remaining task is delivering the final report from the data below.

## Final scores (benchmark skillweaver-webarena-shopping-smoke, 1 run/case)

| case | H1 (v1, empty library) | final (v3, 1 API tested) |
|---|---|---|
| CASE-001-wa21 | 0.00 (210456 ms, session-2026-11-20-06-16-10-54583cb7) | 0.00 (205231 ms, session-2026-11-20-07-02-44-aad21b6a) |
| CASE-002-wa47 | 100.00 (169265 ms, session-2026-11-20-06-21-51-ce43115b) | 100.00 (96971 ms, session-2026-11-20-07-07-52-3bbacc97) |
| CASE-008-wa158 | 0.00 (259034 ms, session-2026-11-20-06-25-50-4567ae6a) | 0.00 (119401 ms, session-2026-11-20-07-11-01-452d3976) |
| average | 33.33 (avg 212918 ms, cost null) | 33.33 (avg 140534 ms, cost null) |

Scoreboard file `<EXPERIMENT_ROOT>/penguin-data/default_project/benchmarks/skillweaver-webarena-shopping-smoke/scoreboard.yaml` now holds both evaluations; re-parsed with python yaml: 2 evaluations, averages verified (33.33/33.33, durations 212918/140534), per-run values consistent.

## API actually used (a read is not a use; a use is not a gain)

- All three final Target traces read `apis/INDEX.md` (1 read each).
- `add_products_to_cart.mjs` was actually invoked only in CASE-008-wa158 (2 calls, first from the library root, then from `apis/`; both added "Game Card Holder Storage Case for Nintendo Switch Games or PS Vita Game Case or SD Memory Cards, Black"). Score stayed 0.00 — the case asks to find the best storage option for 11 Switch cards, so adding to cart was an over-action and not a gain.
- CASE-001 and CASE-002 made no API calls; CASE-002 still scored 100.00 with ordinary browser tools.
- Trace audits of all three final cells: 0 non-browser network calls, 0 Agent-State writes.

## State integrity

- STATE fingerprint before the final matrix (23:01Z) and after (23:14:05Z) both `d1ecac4bb079910c90f97b2faeec4c2175e44dd699d85766640c55091075f44e` → Target State read-only throughout measurement.
- Second sign-in verified by supervisor 2026-11-19T23:01:21.2081470Z; evidence copied to `OUT/final-login.txt`.
- Snapshots: v1 (empty), v2 (iter_0 publish), v3 (iter_1 passing test) all exist under `TARGET/snapshots/` and verified with `tar -dzf`.

## Token records (session totals from trace token_usage events; "in" includes cache reads)

Roles (custom/step-5-preview, thinking medium):
- Proposer iter_0: in 24064 / out 9196 / total 40237
- Judge iter_0 (includes its 1 format correction): in 263680 / out 5539 / total 357702
- Synthesiser iter_0 (includes its 1 format correction): in 271872 / out 26946 / total 365124
- Tester iter_1: in 12800 / out 2200 / total 27266
- Eval worker final CASE-001: in 358144 / out 6384 / total 406048
- Eval worker final CASE-002: in 324864 / out 7104 / total 371636
- Eval worker final CASE-008: in 430336 / out 8837 / total 498890

Target cells:
- iter_0 practice: in 800512 / out 49608 / total 927473
- iter_1 practice: in 58368 / out 1633 / total 68714
- H1 CASE-001: in 452096 / out 10201 / total 497890; H1 CASE-002: in 281856 / out 10850 / total 319202; H1 CASE-008: in 1221888 / out 10157 / total 1285720
- final CASE-001: in 499200 / out 14449 / total 557347; final CASE-002: in 152576 / out 5531 / total 176060; final CASE-008: in 313088 / out 5137 / total 343890

(The H1 eval workers' traces are the same session ids as their Target cells' workers; if per-worker H1 numbers are wanted, extract from MY_TRACES sessions 06:15-06:30 — not needed for the report unless asked.)

## Resets

1. Reset 1 (supervisor-run, before H1): reset done 2026-11-19T22:04:11Z, image sha256:8f9618d9194a46bc9f7bc96dc14deba0b968abce6c393d59cc7cd1dfec86ed6f, http://localhost:7770. Raw: OUT/reset-1.log.
2. Reset 2 (controller-run, after practice): `bash <REPOSITORY>/experiments/skillweaver-webarena/reset-shopping.sh http://localhost:7770`, started 22:59:25Z, reset done 2026-11-19T23:00:00Z, same image sha256. Raw: OUT/reset-2.log. Record: OUT/resets.md.

## Practice log

- iter_0 (explore, u=0.0267): Proposer proposed adding the 3 named products to the cart; practice cell exit 0 (session-2026-11-20-06-34-46-d97d45b9), all three products in cart at qty 1 verified by live cart read; Judge success:true (1 format correction); Synthesiser produced add_products_to_cart.mjs + site.md (1 format correction); checker pass; registered v1; published as State version 2 (library SKILL.md 2026.11.20.2, snapshot v2).
- iter_1 (test, u=0.0274; pick-test --seed 1 named add_products_to_cart): Tester args {"products":"Gingerbread House Kit\nV8 Energy Drink\nSo Delicious CocoWhip","quantity":2}; cell exit 0 (session-2026-11-20-06-57-01-29f1d54d), API called via --args-file, printed {"ok":true,...} all three at qty 2; passing test recorded (tests:1); published as State version 3 (SKILL.md 2026.11.20.3, snapshot v3).

## Final library

One API: `add_products_to_cart(products: string, quantity?: number)` — searches the store by name, submits each listing's add-to-cart form, falls back to the product page's own form with the first/checked choice of required custom options, then reads the cart back. Version 1, 1 test, usage_log has the iter_0 entry. No API was dropped by the checker.

## Deviations/adaptations to report

- Runtime: custom/step-5-preview, thinking medium, fixed for all roles and cells.
- Screenshots unavailable in every iteration (desktop cdp 20s timeout) → all roles worked from page text only; iterations counted as without screenshot.
- One format correction each for Judge and Synthesiser (extra model request, same role slot).
- The audit script's "suspicious network" flag on the Synthesiser trace was the write_file of the candidate script text (verified, not site access).
- 10-action limit is an instruction, not enforced; Target State read-only during execution is an instruction — enforced by fingerprints around cells.
- Scores are from one run per case (smoke drill, not the formal 30-case benchmark; the formal benchmark was never run or read).

## Where the records live

OUT = <EXPERIMENT_ROOT>/penguin-data/default_project/agents/sw_shop_smoke_ctl/scratchpad/session-2026-11-20-06-06-28-41f721c1/skillweaver-rsi-toolkit/sw_shop_smoke-20261119T220911Z/
(experiment.yaml, state.yaml, resets.md, reset-1.log, reset-2.log, final-login.txt, h1/CASE-*-run1.yaml, final/CASE-*-run1.yaml, iter_0/{choose.json,page.txt,practice.md,proposer-reply.json,judge-reply.json,synthesiser-reply.json,candidates/,reply/}, iter_1/{choose.json,page.txt,practice.md,tester-reply.json}, library/v2/, library/v3/)
TARGET = <EXPERIMENT_ROOT>/penguin-data/default_project/agents/sw_shop_smoke (agent_state at version 3, snapshots/v1-v3, workspaces/practice-iter0-*, practice-iter1-*)
