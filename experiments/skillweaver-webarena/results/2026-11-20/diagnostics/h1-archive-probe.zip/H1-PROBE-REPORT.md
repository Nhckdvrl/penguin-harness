# H1 archive regression probe — Target `sw_h1_probe`

Probe of the `skillweaver-rsi-toolkit` initialization path (`references/initialization.md`), run
locally and offline: a fresh Target, an empty skill library, the fixed reader line, and an H1
snapshot verified against the live State item by item. **Result: PASS** — 14/14 initialization
checks and 12/12 archive-vs-State file matches; nothing failed, so nothing was preserved as an
error and no stop was triggered.

## What was done

1. **Target created** — `penguin agent create --agent-id sw_h1_probe --project-id default_project
   --plugins browser-automation --json` (fresh id, version 1, no pre-existing library or snapshot,
   so the initialized State keeps version 1 in place).
2. **Empty library initialized** under `agents/sw_h1_probe/agent_state/skills/skillweaver-apis/`:
   - `SKILL.md` — version `2026.11.20.1`, exact body from initialization.md;
   - `apis/library.json` — site `https://books.toscrape.com`, `apis: {}`;
   - `apis/skillweaver-api.mjs` — byte-for-byte the shipped runtime (sha256
     `0eff1f17…9193935c`, 9951 bytes);
   - `apis/INDEX.md` — "No API has been learned yet.";
   - `site.md` — `# Books to Scrape` (the known title; the site was never accessed and no
     `page.txt` exists).
3. **Reader line** appended once to `agents/sw_h1_probe/agent_state/AGENTS.md` (the file was empty).
4. **No site access, no practice cell, no Benchmark, no role or subagent call** — declared as the
   only adaptation in `OUT/experiment.yaml` (`iterations: 0`).
5. **Snapshot created** — `agents/sw_h1_probe/snapshots/v1.tar.gz`, entries rooted at
   `agent_state/`, `.vault.toml` excluded, 24933 bytes, sha256
   `05223ff8dfc6d35b5c4767ec5133389649936bde67fb8ddc508263ebf1d05a12`. No snapshot existed before;
   none was overwritten.

## Verification evidence

- **Initialization checks** (`verify-pre-snapshot.json`, 14/14 PASS): single `version: 1` field in
  `system_config.yaml`; SKILL.md frontmatter name/directory match and today's version;
  `library.json` names the site with no API; runtime byte-for-byte equal; reader line exactly once;
  INDEX.md empty; no API scripts; `site.md` title.
- **Independent per-file SHA-256 comparison** (new-version rule): the archive was unpacked into an
  empty scratch directory and hashed file by file, independent of the live-State map:
  - `h1-verify/archive-files.sha256` — 12 regular files from the archive;
  - `h1-verify/state-files.sha256` — the same 12 from the live State;
  - `diff` of the two lists: identical; item-by-item: **12 matched, 0 mismatched**, no missing or
    extra files (`.vault.toml` excluded on both sides).
  - Empty-library evidence read from the archived copies: `apis: {}`, "No API has been learned
    yet.", no API scripts, reader line once, `version: 1`.
- **Timing**: live-State map recorded 2026-11-19T21:16:36Z; archive unpacked and verified
  2026-11-19T21:18:07Z; snapshot created between the two (2026-11-19T21:17Z local build).

Records live in the Session scratchpad:
`penguin-data/default_project/agents/sw_init_probe/agent_state/scratchpad/session-2026-11-20-05-14-20-415b0431/skillweaver-rsi-toolkit/sw_h1_probe-20261119T211617Z/`
(`experiment.yaml`, `verify-pre-snapshot.json`, `state.yaml`, `h1-verify/archive-vs-state.md`,
`h1-verify/archive-files.sha256`, `h1-verify/state-files.sha256`, `h1-verify/h1-sha256.json`).

## How to re-verify

```bash
OUT="<EXPERIMENT_ROOT>/penguin-data/default_project/agents/sw_init_probe/agent_state/scratchpad/session-2026-11-20-05-14-20-415b0431/skillweaver-rsi-toolkit/sw_h1_probe-20261119T211617Z"
diff "$OUT/h1-verify/archive-files.sha256" "$OUT/h1-verify/state-files.sha256"   # identical
```

## Left undone / notes

- No H1 measurement on a Benchmark (none given), no final library — this probe stops after
  initialization, per the request.
- `runtime.thinking_level` is recorded as `null`: the environment does not state one.
- GNU tar on this machine needs `--force-local` for `F:` paths and POSIX separators; the snapshot
  itself is a plain gzip tar and portable.
