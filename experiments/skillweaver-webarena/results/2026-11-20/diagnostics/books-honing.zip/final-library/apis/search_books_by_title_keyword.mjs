import { browser, runApi } from "./skillweaver-api.mjs";

export const meta = {
  name: "search_books_by_title_keyword",
  description:
    "Search the whole Books to Scrape catalogue — every page of the 'All products' listing — for books " +
    "whose title contains a keyword, and report each match's title, price and stock status. " +
    "The walk covers the entire category: the total page count is read from the pager ('Page 1 of 50') " +
    "with a regular expression rather than assumed, so the search follows the catalogue as it grows; " +
    "page 1 is index.html and the later pages are page-2.html, page-3.html and so on in the same " +
    "directory. Matching is a case-insensitive substring test on the title, so 'history' also finds " +
    "titles such as 'Histories'. Prices and stock are then re-read from each match's product detail " +
    "page, which is authoritative: a listing shows only 'In stock', while the detail page spells out " +
    "'In stock (N available)'. All pages are fetched inside the site's origin from the opened catalogue " +
    "page, so the entire search is one in-page script regardless of the catalogue's size, and each match " +
    "also reports the catalogue page it was found on.",
  params: {
    keyword: {
      type: "string",
      description: "Word that must appear in a book's title, as a shopper would type it (e.g. 'history').",
    },
  },
  returns:
    "An array of {title, price, in_stock, availability, catalogue_page} in catalogue order: title and " +
    "price as shown on the product detail page (price keeps its currency sign), availability that page's " +
    "full stock text (e.g. 'In stock (20 available)'), in_stock true when that text says the book is in " +
    "stock, and catalogue_page the 1-based listing page the book was found on. [] when no title contains " +
    "the keyword.",
  usage_log: [
    "iter_0: keyword 'history' walked all 50 catalogue pages (1,000 books) and matched 16 books; each " +
    "detail page confirmed the listing price and read 'In stock (N available)' with N between 3 and 20, " +
    "so all 16 matches were reported in stock.",
  ],
};

export async function run({ keyword }) {
  browser.open("/catalogue/category/books_1/index.html");
  browser.waitFor("document.querySelector('article.product_pod')");

  const matches = browser.exec(`
    const needle = ${JSON.stringify(String(keyword).toLowerCase())};
    const pager = document.querySelector('.pager .current');
    const totalPages = pager && /of\\s+(\\d+)/i.test(pager.textContent)
      ? parseInt(/of\\s+(\\d+)/i.exec(pager.textContent)[1], 10)
      : 1;
    const found = [];
    for (let page = 1; page <= totalPages; page++) {
      const response = await fetch(page === 1 ? location.href : 'page-' + page + '.html');
      const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
      for (const pod of doc.querySelectorAll('article.product_pod')) {
        const link = pod.querySelector('h3 a[title]');
        const title = link ? link.getAttribute('title').trim() : '';
        if (!title.toLowerCase().includes(needle)) continue;
        const price = pod.querySelector('.price_color');
        const stock = pod.querySelector('.instock.availability');
        found.push({
          title,
          price: price ? price.textContent.trim() : null,
          availability: stock ? stock.textContent.replace(/\\s+/g, ' ').trim() : null,
          catalogue_page: page,
          product_page: new URL(link.getAttribute('href'), location.href).href,
        });
      }
    }
    const verified = [];
    for (const book of found) {
      const doc = new DOMParser().parseFromString(
        await (await fetch(book.product_page)).text(),
        'text/html'
      );
      const heading = doc.querySelector('h1');
      const price = doc.querySelector('.price_color');
      const stock = doc.querySelector('.availability');
      verified.push({
        title: heading ? heading.textContent.trim() : book.title,
        price: price ? price.textContent.trim() : book.price,
        availability: stock ? stock.textContent.replace(/\\s+/g, ' ').trim() : book.availability,
        catalogue_page: book.catalogue_page,
      });
    }
    return verified;
  `);

  return matches.map((book) => ({
    title: book.title,
    price: book.price,
    in_stock: /in stock/i.test(book.availability || ""),
    availability: book.availability,
    catalogue_page: book.catalogue_page,
  }));
}

runApi(import.meta.url, meta, run);
