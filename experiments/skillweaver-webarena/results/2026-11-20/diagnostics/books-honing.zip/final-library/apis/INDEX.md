# Skill library for https://books.toscrape.com

Each API below is a script beside this file. Call it from the shell as
`node <this directory>/<name>.mjs --args '<JSON object of its parameters>'`; it drives the agent
browser and prints one JSON line, `{"ok":true,"result":…}` or `{"ok":false,"error":"…"}`.
Where the shell mangles quotes (Windows PowerShell), write the JSON to a file and pass
`--args-file <file>` instead.

## search_books_by_title_keyword(keyword: string)

Search the whole Books to Scrape catalogue — every page of the 'All products' listing — for books whose title contains a keyword, and report each match's title, price and stock status. The walk covers the entire category: the total page count is read from the pager ('Page 1 of 50') with a regular expression rather than assumed, so the search follows the catalogue as it grows; page 1 is index.html and the later pages are page-2.html, page-3.html and so on in the same directory. Matching is a case-insensitive substring test on the title, so 'history' also finds titles such as 'Histories'. Prices and stock are then re-read from each match's product detail page, which is authoritative: a listing shows only 'In stock', while the detail page spells out 'In stock (N available)'. All pages are fetched inside the site's origin from the opened catalogue page, so the entire search is one in-page script regardless of the catalogue's size, and each match also reports the catalogue page it was found on.

- `keyword` (string): Word that must appear in a book's title, as a shopper would type it (e.g. 'history').

Returns: An array of {title, price, in_stock, availability, catalogue_page} in catalogue order: title and price as shown on the product detail page (price keeps its currency sign), availability that page's full stock text (e.g. 'In stock (20 available)'), in_stock true when that text says the book is in stock, and catalogue_page the 1-based listing page the book was found on. [] when no title contains the keyword.

Version 1; tested 1 time(s).

Usage log:
- iter_0: keyword 'history' walked all 50 catalogue pages (1,000 books) and matched 16 books; each detail page confirmed the listing price and read 'In stock (N available)' with N between 3 and 20, so all 16 matches were reported in stock.
