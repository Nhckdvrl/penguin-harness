# Books to Scrape

A sandbox bookshop at books.toscrape.com for scraping practice: a fixed catalogue of 1,000 books that
can be browsed by category, with every price quoted in pounds sterling (£).

## All products catalogue

- The whole catalogue is the "All products" category, at /catalogue/category/books_1/index.html. It is
  the only category that holds every book in the shop.
- It lists 20 books per page across 50 pages. Page 1 is index.html; the following pages are page-2.html
  through page-50.html in the same directory.
- A pager sits under the listing and states the position as "Page 1 of 50". Its last number is the
  category's total page count, and reading it is the reliable way to learn how many pages a category
  has; a category that fits on one page has no pager at all.

## Product cards on a listing page

- Each book is an article.product_pod. The title is the title attribute of the h3 link (the visible
  link text repeats it), the price is in .price_color (e.g. £54.23), and the stock note is in
  .instock.availability.
- On a listing the stock note reads only "In stock" or "Out of stock". The number of copies available
  appears on the detail page, not here.
- A book's price is the same on the listing and on its detail page.

## Product detail pages

- Each book has a page at /catalogue/<slug>_<id>/index.html. Links to them from a category page are
  relative (../../<slug>_<id>/index.html), so they must be resolved against the listing page's URL.
- The full title is the page's h1, the price is in .price_color (tax included), and .availability
  spells out stock as "In stock (N available)" or "Out of stock". This is the authoritative place to
  read both the price and the stock status of a book.
