import { browser, runApi } from "./skillweaver-api.mjs";

export const meta = {
  name: "add_category_books_under_price_to_basket",
  description:
    "Add every book in a shop category that is priced under a given amount to the basket. " +
    "The category is found by its visible name in the site's navigation (case-insensitive match on the " +
    "trimmed link text, so no URL or slug is needed), and every page of its listing is walked through " +
    "the pagination control. On each page, the books whose displayed price is strictly below max_price " +
    "are added by clicking the 'Add to basket' control inside their listing entry, which adds the book " +
    "without leaving the listing. Unexpected but useful details: long titles are truncated with an " +
    "ellipsis in the visible text, so the full title is read from the link's title attribute; prices are " +
    "shown prefixed with a currency sign and only the numeric amount is compared. The basket contents " +
    "are not read back — the result reports the books this call added, and an empty list is a normal " +
    "outcome when nothing in the category qualifies.",
  params: {
    category: {
      type: "string",
      description: "Category name as written in the site's side navigation, e.g. 'Travel'.",
    },
    max_price: {
      type: "number",
      description: "Price ceiling in pounds: only books priced strictly below this amount are added.",
    },
  },
  returns:
    "An object {category, added}: added lists, in listing order, each book that was added to the basket " +
    "as {name, price} (price is the amount shown, without the currency sign). It is an empty array when " +
    "no book in the category is priced under max_price.",
  usage_log: [
    "iter_0: category 'Travel', max_price 20 — the listing showed 11 books, every one priced £23.21 or " +
    "above, so nothing qualified and nothing was added; the empty result was the intended outcome for " +
    "the task.",
  ],
};

export async function run({ category, max_price }) {
  browser.open("/");

  const categoryPath = browser.exec(`
    const wanted = ${JSON.stringify(category.trim().toLowerCase())};
    const link = [...document.querySelectorAll("a")].find(
      (a) => a.textContent.trim().toLowerCase() === wanted
    );
    if (!link) return null;
    const url = new URL(link.getAttribute("href"), location.href);
    return url.pathname + url.search;
  `);
  if (!categoryPath) {
    throw new Error("No category named '" + category + "' in the site navigation");
  }

  browser.open(categoryPath);
  browser.waitFor("document.querySelector('.product_pod')");

  const added = [];
  while (true) {
    const qualifying = browser.exec(`
      const ceiling = ${JSON.stringify(max_price)};
      return [...document.querySelectorAll(".product_pod")]
        .map((pod) => {
          const titleLink = pod.querySelector("h3 a");
          const priceText = pod.querySelector(".price_color")?.textContent || "";
          return {
            name: titleLink?.getAttribute("title") || titleLink?.textContent.trim(),
            price: Number(priceText.replace(/[^0-9.]/g, "")),
          };
        })
        .filter((book) => Number.isFinite(book.price) && book.price < ceiling);
    `);

    for (const book of qualifying) {
      browser.exec(`
        const wanted = ${JSON.stringify(book.name)};
        const pods = [...document.querySelectorAll(".product_pod")];
        const pod = pods.find((p) => {
          const link = p.querySelector("h3 a");
          const name = link?.getAttribute("title") || link?.textContent.trim();
          return name === wanted;
        });
        if (!pod) {
          throw new Error("listing entry for '" + wanted + "' disappeared before it could be added");
        }
        const control = [...pod.querySelectorAll("button, a")].find(
          (el) => el.textContent.trim().toLowerCase() === "add to basket"
        );
        if (!control) {
          throw new Error("no 'Add to basket' control in the listing entry for '" + wanted + "'");
        }
        control.click();
      `);
      added.push({ name: book.name, price: book.price });
    }

    const nextPath = browser.exec(`
      const next = document.querySelector("li.next a");
      if (!next) return null;
      const url = new URL(next.getAttribute("href"), location.href);
      return url.pathname + url.search;
    `);
    if (!nextPath) break;
    browser.open(nextPath);
    browser.waitFor("document.querySelector('.product_pod')");
  }

  return { category, added };
}

runApi(import.meta.url, meta, run);
