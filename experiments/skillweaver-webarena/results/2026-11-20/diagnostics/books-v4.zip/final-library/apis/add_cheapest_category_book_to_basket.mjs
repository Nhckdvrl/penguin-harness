import { browser, runApi } from "./skillweaver-api.mjs";

export const meta = {
  name: "add_cheapest_category_book_to_basket",
  description:
    "Add the cheapest book of a shop category to the basket. The category is found by its visible " +
    "name in the site's navigation (case-insensitive match on the trimmed link text, so no URL or " +
    "slug is needed), and every page of its listing is read through the pagination control, so the " +
    "cheapest book is chosen across the whole category and not just the first page. On each page " +
    "the books' full titles are read from the entry's title link, because long titles are " +
    "truncated with an ellipsis in the visible text, and their prices are read from the price " +
    "element, where only the numeric amount is compared. The cheapest book is added by clicking " +
    "the 'Add to basket' control inside its listing entry, which submits that entry's form and " +
    "adds the book without leaving the listing; when several books share the lowest price, the " +
    "first of them in listing order is the one added. Unexpected but useful details: every add " +
    "form on this site has no action and no method, there is no basket page, and no cookie, " +
    "session or client-side storage is kept, so nothing observable changes after the click — the " +
    "click itself is the add gesture the site supports, and the basket contents cannot be read back.",
  params: {
    category: {
      type: "string",
      description: "Category name as written in the site's side navigation, e.g. 'Mystery'.",
    },
  },
  returns:
    "An object {category, book}: book is the cheapest book that was added, as {name, price} " +
    "(price is the amount shown, without the currency sign), or null when the category holds no books.",
  usage_log: [
    "iter_1: category 'Mystery' — the listing held 32 books across two pages; the cheapest was " +
    "'Tastes Like Fear (DI Marnie Rome #3)' at £10.69, a unique minimum (next cheapest £11.84). " +
    "The 'Add to basket' control in that book's entry (pod 7 of the first page) was clicked and " +
    "the click reported success; the checks that followed confirmed the site keeps no readable " +
    "basket state, which is a property of the site rather than a failure of this call.",
  ],
};

export async function run({ category }) {
  browser.open("/");
  browser.waitFor("document.querySelector('a')");

  const listingPath = browser.exec(`
    const wanted = ${JSON.stringify(category)}.trim().toLowerCase();
    const link = [...document.querySelectorAll("a")].find(
      (a) => a.textContent.trim().toLowerCase() === wanted
    );
    return link ? new URL(link.getAttribute("href"), location.href).pathname : null;
  `);
  if (!listingPath) {
    throw new Error("No category named '" + category + "' in the site's navigation");
  }

  const books = [];
  let pagePath = listingPath;
  for (let guard = 0; guard < 50; guard += 1) {
    browser.open(pagePath);
    browser.waitFor("document.querySelector('.product_pod')");
    const listing = browser.exec(`
      const pods = [...document.querySelectorAll(".product_pod")];
      const next = document.querySelector("li.next a");
      return {
        books: pods.map((pod) => {
          const titleLink = pod.querySelector("h3 a");
          const price = pod.querySelector(".price_color");
          return {
            name: (titleLink ? titleLink.getAttribute("title") || titleLink.textContent : "").trim(),
            price: Number((price ? price.textContent : "").replace(/[^0-9.]/g, "")),
          };
        }),
        nextPath: next ? new URL(next.getAttribute("href"), location.href).pathname : null,
      };
    `);
    listing.books.forEach((book, index) => books.push({ ...book, page: pagePath, index }));
    if (!listing.nextPath) {
      break;
    }
    pagePath = listing.nextPath;
  }

  if (books.length === 0) {
    return { category, book: null };
  }

  const cheapest = books.reduce((lowest, book) => (book.price < lowest.price ? book : lowest));

  browser.open(cheapest.page);
  browser.waitFor("document.querySelector('.product_pod button')");
  browser.click(".product_pod button", { index: cheapest.index });

  return { category, book: { name: cheapest.name, price: cheapest.price } };
}

runApi(import.meta.url, meta, run);
