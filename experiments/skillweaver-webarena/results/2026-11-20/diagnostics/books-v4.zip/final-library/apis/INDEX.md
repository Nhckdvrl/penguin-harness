# Skill library for https://books.toscrape.com

Each API below is a script beside this file. Call it from the shell as
`node <this directory>/<name>.mjs --args '<JSON object of its parameters>'`; it drives the agent
browser and prints one JSON line, `{"ok":true,"result":…}` or `{"ok":false,"error":"…"}`.
Where the shell mangles quotes (Windows PowerShell), write the JSON to a file and pass
`--args-file <file>` instead.

## add_category_books_under_price_to_basket(category: string, max_price: number)

Add every book in a shop category that is priced under a given amount to the basket. The category is found by its visible name in the site's navigation (case-insensitive match on the trimmed link text, so no URL or slug is needed), and every page of its listing is walked through the pagination control. On each page, the books whose displayed price is strictly below max_price are added by clicking the 'Add to basket' control inside their listing entry, which adds the book without leaving the listing. Unexpected but useful details: long titles are truncated with an ellipsis in the visible text, so the full title is read from the link's title attribute; prices are shown prefixed with a currency sign and only the numeric amount is compared. The basket contents are not read back — the result reports the books this call added, and an empty list is a normal outcome when nothing in the category qualifies.

- `category` (string): Category name as written in the site's side navigation, e.g. 'Travel'.
- `max_price` (number): Price ceiling in pounds: only books priced strictly below this amount are added.

Returns: An object {category, added}: added lists, in listing order, each book that was added to the basket as {name, price} (price is the amount shown, without the currency sign). It is an empty array when no book in the category is priced under max_price.

Version 1; untested.

Usage log:
- iter_0: category 'Travel', max_price 20 — the listing showed 11 books, every one priced £23.21 or above, so nothing qualified and nothing was added; the empty result was the intended outcome for the task.

## add_cheapest_category_book_to_basket(category: string)

Add the cheapest book of a shop category to the basket. The category is found by its visible name in the site's navigation (case-insensitive match on the trimmed link text, so no URL or slug is needed), and every page of its listing is read through the pagination control, so the cheapest book is chosen across the whole category and not just the first page. On each page the books' full titles are read from the entry's title link, because long titles are truncated with an ellipsis in the visible text, and their prices are read from the price element, where only the numeric amount is compared. The cheapest book is added by clicking the 'Add to basket' control inside its listing entry, which submits that entry's form and adds the book without leaving the listing; when several books share the lowest price, the first of them in listing order is the one added. Unexpected but useful details: every add form on this site has no action and no method, there is no basket page, and no cookie, session or client-side storage is kept, so nothing observable changes after the click — the click itself is the add gesture the site supports, and the basket contents cannot be read back.

- `category` (string): Category name as written in the site's side navigation, e.g. 'Mystery'.

Returns: An object {category, book}: book is the cheapest book that was added, as {name, price} (price is the amount shown, without the currency sign), or null when the category holds no books.

Version 1; untested.

Usage log:
- iter_1: category 'Mystery' — the listing held 32 books across two pages; the cheapest was 'Tastes Like Fear (DI Marnie Rome #3)' at £10.69, a unique minimum (next cheapest £11.84). The 'Add to basket' control in that book's entry (pod 7 of the first page) was clicked and the click reported success; the checks that followed confirmed the site keeps no readable basket state, which is a property of the site rather than a failure of this call.
