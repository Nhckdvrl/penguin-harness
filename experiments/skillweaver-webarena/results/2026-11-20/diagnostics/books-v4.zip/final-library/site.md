# Books to Scrape

Books to Scrape (https://books.toscrape.com, "We love being scraped!") is a demo bookshop built for
web-scraping practice. A banner on the listing pages states: "Warning! This is a demo website for web
scraping purposes. Prices and ratings here were randomly assigned and have no real meaning."

## Home page and category navigation

The home page carries a side navigation that lists every category of the shop. Each entry is a link
whose visible text is the category name; following it opens that category's listing page. The
categories, in navigation order, are: Books, Travel, Mystery, Historical Fiction, Sequential Art,
Classics, Philosophy, Romance, Womens Fiction, Fiction, Childrens, Religion, Nonfiction, Music,
Default, Science Fiction, Sports and Games, Fantasy, New Adult, Young Adult, Science, Poetry,
Paranormal, Art, Psychology, Autobiography, Parenting, Adult Fiction, Humor, Horror, History,
Food and Drink, Christian Fiction, Business, Biography, Thriller, Contemporary, Spirituality,
Academic, Self Help, Historical, Christian, Suspense, Short Stories, Novels, Health, Politics,
Cultural, Erotica, Crime, Travel.

## Category listing pages

A category page is titled with the category name and summarises its contents with a line such as
"11 results." below the navigation. It then lists the books of the category; when a category is
longer than one page, a pagination control ("next") moves to the following page. A listing page
holds up to twenty books, so a longer category is spread over consecutively numbered pages reached
through that control — the Mystery category, for example, holds thirty-two books on two pages. A
statement about a whole category, such as which of its books is the cheapest, therefore needs every
one of its pages read.

## Book entries

Each book is shown as a listing entry with its title, its price prefixed with the £ sign, its stock
status ("In stock"), and an "Add to basket" control. Long titles may appear truncated with an
ellipsis in the visible text, while the entry's title link carries the full title. An entry holds
exactly one "Add to basket" control, so the controls on a page follow the order of the entries and
can be counted and addressed one book at a time.

## Book detail pages

Each book also has a page of its own, opened from its listing entry. It shows the book's full title
and repeats the "Add to basket" control; the detail page observed carried several of those controls,
every one of them the same form as on the listings. No link to a basket appears anywhere on the site.

## Basket

The "Add to basket" control sits inside a book's listing entry, and on its detail page, and is the
site's only add gesture: activating it submits that entry's form — the button can be seen entering
an "Adding..." loading state — which is meant to add the book without leaving the listing page.
Unexpected but important: the form carries no action and no method, and this replica of the shop
keeps no basket of any kind. The shop is served as a static copy of the real one (its page titles end
in "- Sandbox"); submitting the form sends no request, navigates nowhere and writes no cookie,
session or client-side storage, and the site's basket address answers 404. There is consequently no
basket state to read back: clicking a book's control is as far as adding it to the basket can be
observed to go, and an automation can only report which books' controls it activated — a category
whose books all fall outside a caller's price ceiling contributes no add gestures at all.
