# Skill library for https://books.toscrape.com

Each API below is a script beside this file. Call it from the shell as
`node <this directory>/<name>.mjs --args '<JSON object of its parameters>'`; it drives the agent
browser and prints one JSON line, `{"ok":true,"result":…}` or `{"ok":false,"error":"…"}`.
Where the shell mangles quotes (Windows PowerShell), write the JSON to a file and pass
`--args-file <file>` instead.

## add_cheapest_in_stock_books_to_basket(category: string, count?: number)

Add the cheapest in-stock books of a category to the basket. The category is named as the site spells it in its sidebar (e.g. "Travel"): the script opens the home page, follows the matching category link, then follows every "next" page link until the last result page, so a category with any number of result pages is read in full. Books are ranked by the price shown on the listing, as a number of pounds without the "£" sign; equal prices keep listing order, and only books whose listing says "In stock" are considered. Each chosen book is added from its own product page by clicking the "Add to basket" button, matched by its visible text. Two behaviours are normal on this site and worth knowing: the first navigation of a session sometimes serves a blank page, so the script waits for the listing and the button instead of reading immediately; and the sandbox has no basket backend, so an add has no persistent effect beyond reloading the page, and the returned `added` flag reports only that the button was found and clicked. If the category holds fewer in-stock books than asked for, all of them are added.

- `category` (string): Category name as the site's sidebar shows it, e.g. "Travel".
- `count` (number, optional): How many of the cheapest in-stock books to add. Defaults to 3.

Returns: The books added, cheapest first, as {title, price, path, added}: the full title, the price in pounds as a number, the product-page path on the site, and whether the "Add to basket" button was found and clicked. [] when the category has no in-stock book.

Version 1; untested.

Usage log:
- iter_1: category 'Travel', count 3 - the category listed 11 books, all in stock, on a single result page (no next-page link); added 'The Road to Little Dribbling' (£23.21), '1,000 Places to See Before You Die' (£26.08) and 'The Great Railway Bazaar' (£30.54). Each 'Add to basket' button was found and clicked and the page reloaded; the sandbox keeps no basket, so the click itself is the only confirmation. The attempt was judged successful.
