import { browser, runApi } from "./skillweaver-api.mjs";

export const meta = {
  name: "add_cheapest_in_stock_books_to_basket",
  description:
    "Add the cheapest in-stock books of a category to the basket. The category is named as the " +
    "site spells it in its sidebar (e.g. \"Travel\"): the script opens the home page, follows the " +
    "matching category link, then follows every \"next\" page link until the last result page, so " +
    "a category with any number of result pages is read in full. Books are ranked by the price " +
    "shown on the listing, as a number of pounds without the \"£\" sign; equal prices keep " +
    "listing order, and only books whose listing says \"In stock\" are considered. Each chosen " +
    "book is added from its own product page by clicking the \"Add to basket\" button, matched by " +
    "its visible text. Two behaviours are normal on this site and worth knowing: the first " +
    "navigation of a session sometimes serves a blank page, so the script waits for the listing " +
    "and the button instead of reading immediately; and the sandbox has no basket backend, so an " +
    "add has no persistent effect beyond reloading the page, and the returned `added` flag " +
    "reports only that the button was found and clicked. If the category holds fewer in-stock " +
    "books than asked for, all of them are added.",
  params: {
    category: {
      type: "string",
      description: "Category name as the site's sidebar shows it, e.g. \"Travel\".",
    },
    count: {
      type: "number",
      description: "How many of the cheapest in-stock books to add. Defaults to 3.",
      optional: true,
    },
  },
  returns:
    "The books added, cheapest first, as {title, price, path, added}: the full title, the price " +
    "in pounds as a number, the product-page path on the site, and whether the \"Add to basket\" " +
    "button was found and clicked. [] when the category has no in-stock book.",
  usage_log: [
    "iter_1: category 'Travel', count 3 - the category listed 11 books, all in stock, on a " +
    "single result page (no next-page link); added 'The Road to Little Dribbling' (£23.21), " +
    "'1,000 Places to See Before You Die' (£26.08) and 'The Great Railway Bazaar' (£30.54). " +
    "Each 'Add to basket' button was found and clicked and the page reloaded; the sandbox keeps " +
    "no basket, so the click itself is the only confirmation. The attempt was judged successful.",
  ],
};

export async function run({ category, count = 3 }) {
  if (!Number.isInteger(count) || count < 1) {
    throw new Error(`"count" must be a whole number of at least 1, got ${count}`);
  }

  // The sidebar on the home page links every category; take this one's listing page.
  browser.open("/");
  const categoryPath = browser.exec(`
    const wanted = ${JSON.stringify(category.trim().toLowerCase())};
    const link = [...document.querySelectorAll("a")].find(
      (a) => a.textContent.trim().toLowerCase() === wanted,
    );
    return link ? new URL(link.href).pathname : null;
  `);
  if (categoryPath === null) {
    throw new Error(`no category named "${category}" in the site's sidebar`);
  }

  // Page through every result page of the category.
  browser.open(categoryPath);
  const books = [];
  for (;;) {
    const ready = browser.waitFor("document.querySelector('article.product_pod')", {
      timeoutMs: 15000,
    });
    if (!ready) throw new Error(`the result page at ${categoryPath} showed no books`);
    const page = browser.exec(`
      const books = [...document.querySelectorAll("article.product_pod")].map((pod) => {
        const link = pod.querySelector("h3 a");
        return {
          title: (link?.getAttribute("title") ?? link?.textContent ?? "").trim(),
          price: Number((pod.querySelector(".price_color")?.textContent ?? "").replace(/[^\\d.]/g, "")),
          inStock: /in stock/i.test(pod.querySelector(".availability")?.textContent ?? ""),
          path: new URL(link.href).pathname,
        };
      });
      const next = document.querySelector("li.next a");
      return { books, next: next ? new URL(next.href).pathname : null };
    `);
    books.push(...page.books);
    if (page.next === null) break;
    browser.open(page.next);
  }

  // The cheapest in-stock books, cheapest first.
  const chosen = books
    .filter((book) => book.inStock)
    .sort((a, b) => a.price - b.price)
    .slice(0, count);

  // Add each one from its own product page.
  const added = [];
  for (const book of chosen) {
    browser.open(book.path);
    const ready = browser.waitFor(
      "[...document.querySelectorAll('button')].some((b) => b.textContent.trim() === 'Add to basket')",
      { timeoutMs: 15000 },
    );
    if (!ready) throw new Error(`no "Add to basket" button on the page of "${book.title}"`);
    const clicked = browser.exec(`
      const button = [...document.querySelectorAll("button")].find(
        (b) => b.textContent.trim() === "Add to basket",
      );
      if (button === undefined) return false;
      button.click();
      return true;
    `);
    added.push({ title: book.title, price: book.price, path: book.path, added: clicked });
  }
  return added;
}

runApi(import.meta.url, meta, run);
