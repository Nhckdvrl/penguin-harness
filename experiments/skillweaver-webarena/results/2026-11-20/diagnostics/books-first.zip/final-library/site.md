# Books to Scrape & Sandbox

A sandbox of an online bookshop: a browsable catalogue of books priced in pounds sterling, a
category tree, product pages and an "Add to basket" button. There is no checkout and the site is
effectively read-only, because the one action a page offers, adding a book to the basket, has no
effect beyond reloading the page. Page titles end with "Books to Scrape - Sandbox".

## Home page

Titled "All products". It shows the catalogue as a paginated list of books and carries a sidebar
with a link to every category. Each category link opens that category's listing page, whose
address follows the pattern /catalogue/category/books/<category>_<n>/index.html.

## Category pages

Headed with the category name and showing that category's books as a list of product cards. Each
card holds the book's full title (both as the link text and in the link's title attribute), the
price with a leading "£", the availability ("In stock" for the books seen here), and a link to the
book's product page.

## Pagination

Listing pages - the home page and the category pages - show twenty books per page with a "next"
button at the bottom. The button is absent on the last page, so its absence is how the end of the
results is recognised; the Travel category, for example, fits on a single page, while the Mystery
category spans two. Because a category's cheapest book can sit on any page, finding the cheapest
means reading every result page.

## Product pages

Titled with the book's full title. A product page repeats the title, the same price and the
availability, and offers a single action: an "Add to basket" button inside a form that posts back
to the same page.

## The basket

Unexpected but consistent: there is no basket. Submitting the "Add to basket" form reloads the
product page and changes nothing else - no basket page, item count or total exists anywhere on
the site, and a later visit shows no trace of the add. An add can therefore only be confirmed by
the click itself and the page reload that follows it, never by stored state. A related quirk: the
first navigation of a browser session sometimes serves a blank page, so reading a page before it
has loaded returns nothing; waiting for the listing or the button before reading avoids it.

## Prices

Every price is in pounds sterling, shown with a leading "£", and a book's price is the same on
the listing and on its product page.
