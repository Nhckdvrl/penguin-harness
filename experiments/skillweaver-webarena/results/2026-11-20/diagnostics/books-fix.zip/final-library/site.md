# Books to Scrape

https://books.toscrape.com — "Books to Scrape: We love being scraped!", a demo bookstore built on the
django-oscar framework for web-scraping practice. Every product page carries a warning that prices and
ratings were randomly assigned and have no real meaning. The catalogue is plain server-rendered HTML, so
category and product pages can be read by fetching them (same-origin) as well as in the browser.

## Homepage and navigation

- The homepage (`/`, titled "All products") lists the first page of the whole catalogue as product pods.
- The sidebar (`.side_categories`) lists every category — Books, Travel, Mystery, Classics, … — each
  linking to `/catalogue/category/books/<slug>_<n>/index.html`. Category names are unique and match the
  sidebar link text exactly.
- Inner pages carry a breadcrumb (Home › Books › <Category> › <Title>); on a product page it is the
  reliable way back to the book's category.

## Category listing pages

- A listing page shows up to 20 books as `article.product_pod` elements; pagination continues through
  the `next` link (`page-2.html`, `page-3.html`, …), so a category can span several pages.
- A pod holds: a link in its `h3` whose `title` attribute carries the book's full title (the visible
  text can be truncated) and whose href is the product page; the price in `.price_color`, displayed
  with a leading currency sign (e.g. `£10.69`); stock availability; a star rating; and an "Add to
  basket" button.
- Book counts change as the sandbox is regenerated; as of 2026-11-20 Travel held 11 books, Mystery 32
  and Classics 19.

## Product pages

- `/catalogue/<slug>_<id>/index.html` shows the title, price, availability ("In stock (N available)"),
  star rating, product description and a product information table (UPC, tax-inclusive and
  tax-exclusive price, availability, number of reviews).
- Unexpected but important: a product page has no "Add to basket" button for the book itself. The only
  "Add to basket" buttons on a product page belong to the "Products you recently viewed" pods of other
  books. To add a particular book to the basket, click the button on its pod in a category listing page.

## Add to basket

- Each "Add to basket" button is a submit button inside its own bare form with no action or method.
- The site's JavaScript (`static/oscar/js/oscar/ui.js`) has a delegated click handler on
  `[data-loading-text]`: it sets the button's label to "Adding..." and disables it, after which the form
  GET-submits to the current URL and the page reloads (the URL gains a trailing `?`).
- The sandbox has no real basket: `/basket/` returns 404, the header shows no basket link or counter,
  and a click creates no cookie and no localStorage entry. The trusted click on a book's own button is
  therefore the site's entire add-to-basket action, and there is no persistent state to check it
  against afterwards.

## Prices and titles

- Prices always carry the currency sign; read the number by stripping everything but digits and the
  decimal point.
- The full book title is the `title` attribute of the pod's link, on both listing and product pages.
