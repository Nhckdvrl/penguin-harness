import { browser, runApi } from "./skillweaver-api.mjs";

export const meta = {
  name: "add_book_to_basket_from_category",
  description:
    "Add a book to the basket by clicking the book's own 'Add to basket' button on its pod in a " +
    "category listing page, with trusted mouse events; the result echoes the clicked book's title and " +
    "price read back from the listing page after the click. The listing page holding the book is found " +
    "by walking the category's pagination, so a book on any page of the category works. Note that a " +
    "product page has no add-to-basket button of its own — its only 'Add to basket' buttons belong to " +
    "the 'Products you recently viewed' pods of other books — which is why this skill works from the " +
    "listing page. The site's add-to-basket form is action-less: the click briefly sets the button " +
    "label to 'Adding...' and then GET-submits the form, reloading the listing page (its URL gains a " +
    "trailing '?'). This sandbox keeps no basket state (/basket/ returns 404 and no cookie or " +
    "localStorage entry is created), so the trusted click on the book's own button is the site's " +
    "entire add-to-basket action.",
  params: {
    category: {
      type: "string",
      description: "Category name as shown in the sidebar, e.g. 'Mystery'.",
    },
    title: {
      type: "string",
      description: "Full book title as shown on the site, e.g. 'Tastes Like Fear (DI Marnie Rome #3)'.",
    },
  },
  returns:
    "{category, title, price, price_text, clicked: true} — title, price and price_text are read from " +
    "the book's pod on the listing page after the click, confirming which button was clicked.",
  usage_log: [
    "iter_0: category 'Mystery', title 'Tastes Like Fear (DI Marnie Rome #3)' — the book was pod index 7 " +
      "of 20 on the category's first page; its 'Add to basket' button was clicked with trusted events and " +
      "the page reloaded with a trailing '?' as the action-less form GET-submitted. No cookie or " +
      "localStorage entry appeared and /basket/ is 404, i.e. this sandbox has no persistent basket, so " +
      "the click itself was the whole action.",
  ],
};

export async function run({ category, title }) {
  browser.open("/");
  if (browser.waitFor("document.querySelector('.side_categories a')") !== true) {
    throw new Error("the shop homepage did not load its category sidebar");
  }
  const located = browser.exec(
    `
    const category = ${JSON.stringify(category)};
    const title = ${JSON.stringify(title)};
    const link = [...document.querySelectorAll('.side_categories a')]
      .find((a) => a.textContent.trim() === category);
    if (!link) return { found: false, reason: 'category' };
    let url = new URL(link.getAttribute('href'), location.href);
    while (url) {
      const html = await (await fetch(url)).text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const pods = [...doc.querySelectorAll('.product_pod')];
      const index = pods.findIndex(
        (pod) => (pod.querySelector('h3 a')?.getAttribute('title') ?? '') === title
      );
      if (index !== -1) {
        const priceText = (pods[index].querySelector('.price_color')?.textContent ?? '').trim();
        return {
          found: true,
          page_path: url.pathname,
          price: parseFloat(priceText.replace(/[^0-9.]/g, '')),
          price_text: priceText,
        };
      }
      const next = doc.querySelector('.next a');
      url = next ? new URL(next.getAttribute('href'), url) : null;
    }
    return { found: false, reason: 'title' };
  `,
    { timeout: "60s" }
  );
  if (!located.found) {
    throw new Error(
      located.reason === "category"
        ? `no category named ${JSON.stringify(category)} in the shop sidebar`
        : `no book titled ${JSON.stringify(title)} in category ${JSON.stringify(category)}`
    );
  }
  browser.open(located.page_path);
  if (browser.waitFor("document.querySelector('.product_pod button')") !== true) {
    throw new Error("the category listing page did not load its product pods");
  }
  const podIndex = browser.exec(`
    const title = ${JSON.stringify(title)};
    const pods = [...document.querySelectorAll('.product_pod')];
    return pods.findIndex((pod) => (pod.querySelector('h3 a')?.getAttribute('title') ?? '') === title);
  `);
  if (podIndex === -1) {
    throw new Error(`the book titled ${JSON.stringify(title)} is no longer on its listing page`);
  }
  browser.click(".product_pod button", { index: podIndex });
  if (browser.waitFor("document.querySelector('.product_pod button')") !== true) {
    throw new Error("the listing page did not come back after the add-to-basket click");
  }
  const clicked = browser.exec(`
    const title = ${JSON.stringify(title)};
    const pod = [...document.querySelectorAll('.product_pod')]
      .find((p) => (p.querySelector('h3 a')?.getAttribute('title') ?? '') === title);
    const priceText = (pod?.querySelector('.price_color')?.textContent ?? '').trim();
    return {
      title: pod?.querySelector('h3 a')?.getAttribute('title') ?? null,
      price: parseFloat(priceText.replace(/[^0-9.]/g, '')),
      price_text: priceText,
    };
  `);
  return {
    category,
    title: clicked.title,
    price: clicked.price,
    price_text: clicked.price_text,
    clicked: true,
  };
}

runApi(import.meta.url, meta, run);
