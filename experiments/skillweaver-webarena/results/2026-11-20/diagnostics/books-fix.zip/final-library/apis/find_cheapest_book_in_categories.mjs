import { browser, runApi } from "./skillweaver-api.mjs";

export const meta = {
  name: "find_cheapest_book_in_categories",
  description:
    "Scrape every page of the named shop categories and return the cheapest book overall, plus the " +
    "cheapest book and the book count of each category for comparison. Category names are matched " +
    "against the sidebar category links (first match wins) and pagination is followed through each " +
    "category's 'next' links, so every book in a category is considered, not just the first page. " +
    "Prices are read from each pod's price element, which carries a currency sign, and are returned " +
    "both as a number and as the displayed text. Titles come from the pod link's title attribute, " +
    "which holds the full title even when the visible text is truncated. A name that matches no " +
    "sidebar category is skipped and listed in the result instead of failing the whole call.",
  params: {
    categories: {
      type: "string",
      description: "Comma-separated category names as shown in the sidebar, e.g. 'Travel, Mystery, Classics'.",
    },
  },
  returns:
    "{cheapest: {title, price, price_text, category, product_url} | null, per_category: " +
    "[{category, book_count, cheapest: {title, price, price_text, product_url} | null}], " +
    "skipped_categories: [string]}. cheapest is null when none of the named categories held a book; " +
    "price is a number without the currency sign; product_url is the book's product page.",
  usage_log: [
    "iter_0: categories 'Travel, Mystery, Classics' returned cheapest 'Tastes Like Fear (DI Marnie Rome #3)' " +
      "at £10.69 (Mystery), with per-category cheapest 'The Road to Little Dribbling: Adventures of an American " +
      "in Britain (Notes From a Small Island #2)' £23.21 (Travel, 11 books) and 'The Hound of the Baskervilles " +
      "(Sherlock Holmes #5)' £14.82 (Classics, 19 books); Mystery held 32 books across 2 pages.",
  ],
};

export async function run({ categories }) {
  const wanted = String(categories)
    .split(",")
    .map((name) => name.trim())
    .filter(Boolean);
  browser.open("/");
  if (browser.waitFor("document.querySelector('.side_categories a')") !== true) {
    throw new Error("the shop homepage did not load its category sidebar");
  }
  return browser.exec(
    `
    const wanted = ${JSON.stringify(wanted)};

    async function scrapeCategory(startUrl) {
      const books = [];
      let url = startUrl;
      while (url) {
        const html = await (await fetch(url)).text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        for (const pod of doc.querySelectorAll('.product_pod')) {
          const link = pod.querySelector('h3 a');
          const priceText = (pod.querySelector('.price_color')?.textContent ?? '').trim();
          books.push({
            title: link?.getAttribute('title') ?? link?.textContent.trim() ?? '',
            price: parseFloat(priceText.replace(/[^0-9.]/g, '')),
            price_text: priceText,
            product_url: link ? new URL(link.getAttribute('href'), url).href : null,
          });
        }
        const next = doc.querySelector('.next a');
        url = next ? new URL(next.getAttribute('href'), url).href : null;
      }
      return books;
    }

    const home = await (await fetch('/index.html')).text();
    const homeDoc = new DOMParser().parseFromString(home, 'text/html');
    const sidebarLinks = [...homeDoc.querySelectorAll('.side_categories a')].map((a) => ({
      name: a.textContent.trim(),
      url: new URL(a.getAttribute('href'), location.href).href,
    }));
    const found = [];
    const skipped = [];
    for (const name of wanted) {
      const link = sidebarLinks.find((c) => c.name === name);
      if (link) found.push(link);
      else skipped.push(name);
    }
    const perCategory = [];
    let cheapest = null;
    for (const category of found) {
      const books = await scrapeCategory(category.url);
      const best = books.slice().sort((a, b) => a.price - b.price)[0] ?? null;
      if (best && (!cheapest || best.price < cheapest.price)) {
        cheapest = { ...best, category: category.name };
      }
      perCategory.push({
        category: category.name,
        book_count: books.length,
        cheapest: best
          ? { title: best.title, price: best.price, price_text: best.price_text, product_url: best.product_url }
          : null,
      });
    }
    return { cheapest, per_category: perCategory, skipped_categories: skipped };
  `,
    { timeout: "120s" }
  );
}

runApi(import.meta.url, meta, run);
