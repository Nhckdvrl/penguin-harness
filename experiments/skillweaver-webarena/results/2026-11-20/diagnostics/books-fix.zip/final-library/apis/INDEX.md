# Skill library for https://books.toscrape.com

Each API below is a script beside this file. Call it from the shell as
`node <this directory>/<name>.mjs --args '<JSON object of its parameters>'`; it drives the agent
browser and prints one JSON line, `{"ok":true,"result":…}` or `{"ok":false,"error":"…"}`.
Where the shell mangles quotes (Windows PowerShell), write the JSON to a file and pass
`--args-file <file>` instead.

## add_book_to_basket_from_category(category: string, title: string)

Add a book to the basket by clicking the book's own 'Add to basket' button on its pod in a category listing page, with trusted mouse events; the result echoes the clicked book's title and price read back from the listing page after the click. The listing page holding the book is found by walking the category's pagination, so a book on any page of the category works. Note that a product page has no add-to-basket button of its own — its only 'Add to basket' buttons belong to the 'Products you recently viewed' pods of other books — which is why this skill works from the listing page. The site's add-to-basket form is action-less: the click briefly sets the button label to 'Adding...' and then GET-submits the form, reloading the listing page (its URL gains a trailing '?'). This sandbox keeps no basket state (/basket/ returns 404 and no cookie or localStorage entry is created), so the trusted click on the book's own button is the site's entire add-to-basket action.

- `category` (string): Category name as shown in the sidebar, e.g. 'Mystery'.
- `title` (string): Full book title as shown on the site, e.g. 'Tastes Like Fear (DI Marnie Rome #3)'.

Returns: {category, title, price, price_text, clicked: true} — title, price and price_text are read from the book's pod on the listing page after the click, confirming which button was clicked.

Version 1; tested 1 time(s).

Usage log:
- iter_0: category 'Mystery', title 'Tastes Like Fear (DI Marnie Rome #3)' — the book was pod index 7 of 20 on the category's first page; its 'Add to basket' button was clicked with trusted events and the page reloaded with a trailing '?' as the action-less form GET-submitted. No cookie or localStorage entry appeared and /basket/ is 404, i.e. this sandbox has no persistent basket, so the click itself was the whole action.

## find_cheapest_book_in_categories(categories: string)

Scrape every page of the named shop categories and return the cheapest book overall, plus the cheapest book and the book count of each category for comparison. Category names are matched against the sidebar category links (first match wins) and pagination is followed through each category's 'next' links, so every book in a category is considered, not just the first page. Prices are read from each pod's price element, which carries a currency sign, and are returned both as a number and as the displayed text. Titles come from the pod link's title attribute, which holds the full title even when the visible text is truncated. A name that matches no sidebar category is skipped and listed in the result instead of failing the whole call.

- `categories` (string): Comma-separated category names as shown in the sidebar, e.g. 'Travel, Mystery, Classics'.

Returns: {cheapest: {title, price, price_text, category, product_url} | null, per_category: [{category, book_count, cheapest: {title, price, price_text, product_url} | null}], skipped_categories: [string]}. cheapest is null when none of the named categories held a book; price is a number without the currency sign; product_url is the book's product page.

Version 1; untested.

Usage log:
- iter_0: categories 'Travel, Mystery, Classics' returned cheapest 'Tastes Like Fear (DI Marnie Rome #3)' at £10.69 (Mystery), with per-category cheapest 'The Road to Little Dribbling: Adventures of an American in Britain (Notes From a Small Island #2)' £23.21 (Travel, 11 books) and 'The Hound of the Baskervilles (Sherlock Holmes #5)' £14.82 (Classics, 19 books); Mystery held 32 books across 2 pages.
